define(
"dijit/nls/pt-pt/common", ({
	buttonOk: "OK",
	buttonCancel: "Cancelar",
	buttonSave: "Guardar",
	itemClose: "Fechar"
})
);
