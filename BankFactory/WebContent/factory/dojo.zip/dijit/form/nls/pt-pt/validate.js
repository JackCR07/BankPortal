define(
"dijit/form/nls/pt-pt/validate", ({
	invalidMessage: "O valor introduzido não é válido.",
	missingMessage: "Este valor é requerido.",
	rangeMessage: "Este valor encontra-se fora do intervalo."
})
);
