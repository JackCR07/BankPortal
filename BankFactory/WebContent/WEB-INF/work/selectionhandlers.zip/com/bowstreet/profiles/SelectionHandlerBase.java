/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

package com.bowstreet.profiles;

import java.util.*;

import javax.servlet.http.*;

import com.bowstreet.appserver.log4j.LogCategory;
import com.bowstreet.util.StringUtil;
import com.bowstreet.webapp.engine.WebAppRuntimeException;
import com.bowstreet.webapp.util.*;
import com.bowstreet.BSConfig;

/**
 * Base class for creating a ProfileSelection implementation. This class provides the base functionality
 * for matching segments to a profile and handling the processing of explicit profile validation and selection.
 *
 * @include
 *
 */
abstract public class SelectionHandlerBase implements ProfileSelection
{
    protected Map properties = null;

    /** Name of the property for getting the name of the Factory Administrator Role */
    public static final String BOWSTREET_ADMINISTRATORS_NAME_PROPERTY = "bowstreet.security.bowstreetAdministratorsName"; //$NON-NLS-1$

    protected static String bowstreetAdministrators = BSConfig.getProperty(BOWSTREET_ADMINISTRATORS_NAME_PROPERTY, "IBMAdministrators"); //$NON-NLS-1$

    /** Name of the session attribute for specifying we are in development mode, where explicit profile selection rules are relaxed for testing purposes */
    public final static String FROM_DESIGNER_SESSION_KEY = "bowstreet.fromDesigner"; //$NON-NLS-1$

    /**  Used to match segments to prrofile */
    protected  ProfileSetStorageManager  profileStorageManager = new ProfileSetStorageManager();

    public static final Iterator emptyIterator = new Vector().iterator();


    /**
     * Initialization method that is used to pass handler properties to implementers of the ProfileSelection interface.
     * Implementers of this interface should use this method to do any required Initialization before the selectProfile(..) method is called.
     *
     * @param properties A Map of name value pairs specified in the handler definition file. The Map key and values are both of type java.lang.String.
     *
     */
    public void init(Map properties)
    {
        this.properties = properties;
    }


    /**
     * Gets the name of the Profile that matches one of the specified segments.
     * If a segment match is not found then the "Default" profile name is returned.
     *
     * @param profileSetName The name of the ProfileSet to find the matching profile in.
     * @param segments An Iterator of segment names that the user is in.
     * @return The name of the matching Profile, or "Default" if there was no match.
     *
     */
    public String getProfileBySegment(String profileSetName, Iterator segments)
    {
       String profileName = Profile.DEFAULT;
       int maxDepth = 0;

        // get an Iterator of all the Profiles that match the segment names
        Iterator profileNames = profileStorageManager.getProfilesBySegment(profileSetName, segments);

        // now find the deepest one using the name (i.e. acme.hr.foo).
        while(profileNames.hasNext())
        {
            ProfileDescription profileDescription = (ProfileDescription)profileNames.next();
            String name = profileDescription.getName();

            int depth = getDepth(name);

            if(depth > maxDepth)
                profileName = name;

        }

        return profileName;

    }



   /**
     * Validates the explicit profile to see if it should be used as the selection.
     * This will check to make sure the profile exists in the profile set, and that the user's segment matches one of the profiles segments.
     *
     * If the profile does not exits or the segments don't match a WebAppRuntimeException will be thrown. This is an unchecked exception.
     *
     * If the server is in the development mode(inDevelopmentMode = true) or the user is the Factory Administrators role then this will return true.
     * This allows developers to test their app with different explicit profiles.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param explicitProfile The name of the explicit profile to validate.
     * @param profileSet The profile set name to validate against. This method will make sure that the explicit profile exists in this profile set.
     * @param segments The segments for the current user. This method will check if the user's segment matches one of the profiles segments
     * @return true if an explicit profile was passed in, else false. If this method return true your selectProfile(..) method should return the value of its explicitProfile argument.
     *
     */
   public boolean validateExplicitProfile(HttpServletRequest request, String explicitProfile, ProfileSet profileSet, Iterator segments)
   {
        boolean valid = false;

        // See if there was an explicit profile specified
        if(explicitProfile != null && explicitProfile.length() > 0)
        {
            // Get profile from cache.
            Profile profile = ProfileCache.getProfileCache().getProfile(profileSet.getName(), explicitProfile);
            if(profile == null)
            {
                String msg = StringUtil.printf(ProfileRes.getString("SelectionHandlerBase.0"), explicitProfile); //$NON-NLS-1$
                throw new WebAppRuntimeException(msg);
            }

            // Check for null, which could happen when generation happens from the Designer (IDE).
            if (request == null)
            {
                return true;
            }

            // First, see if any roles specified on the profile, if not then any Role is ok.
            if (!profile.rolesExist())
            {
                return true;
            }

            // if in the bowstreetAdministrators role then allow them to use any explicit profile.
            if(request.isUserInRole(bowstreetAdministrators))
                return true;


            // see if the user hit us from the designer at some point.
            boolean fromDesigner = fromDesigner(request);

            // see if the user's segment matches one of the profiles segments
            if(!fromDesigner && isSegmentInProfile(request, profile, segments) == false)
            {
                String msg = StringUtil.printf(ProfileRes.getString("SelectionHandlerBase.1"), profile.getName()); //$NON-NLS-1$
                throw new WebAppRuntimeException(msg);
            }

            valid = true;
        }

        return valid;
    }

    /**
     * Tests to see if there is a matching segment for the specified profile.
     *
     * If the user is the Factory Administrators role then this will return true.
     * This allows developers to test their app with different explicit profiles.
     *
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profile The profile that the match will be performed on.
     * @param segments an Iterator on segment names that the used is a member of.
     * @return true if one of the segments matches one on the profile, or true if the profile has no segments defined, else false if no match.
     *
     */
    public boolean isSegmentInProfile(HttpServletRequest request, Profile profile, Iterator segments)
    {
        // If no segments, then no match.
        if (segments == null)
        {
            return false;
        }

        // Loop through the segments and make sure one of them matches one in the profile.
        while(segments.hasNext())
        {
            String segmentName = (String)segments.next();

            // see if there is a match
            if(profile.containsRole(segmentName))
                return true;
        }

        return false;
    }



    /**
     * Gets the id of the user by calling the getUserID() method on the UserInfo class.
     *
     * @param request The HttpServletRequest for the current request.
     * @return The user ID of the current user (e.g. msmith), or null if the user is not authenticated.
     *
     */
    public String getUserID(HttpServletRequest request)
    {
        String userID = null;
        // Gets the ID of the user. If not authenticated this will be null.
        UserInfo userInfo = UserInfoHandlerFactory.getUserInfo(request);
        if(userInfo != null)
        {
            // get the user ID of the current user (e.g. msmith)
            userID = userInfo.getUserID();
        }

        return userID;
    }

    /**
     * @param request The HttpServletRequest for the current request.
     *
     * @return true if the user has hit the server through the Designer at some point in their session, else false
     */
    protected boolean fromDesigner(HttpServletRequest request)
    {
            // see if the user hit us from the designer at some point.
            String fromDesigner = (String)request.getSession().getAttribute(FROM_DESIGNER_SESSION_KEY);
            return "true".equals(fromDesigner); //$NON-NLS-1$
    }

   /**
     * Finds the depth of the profile using its name.
     *
     * @param ProfileName The qualified name of the Profile (e.g. acme.hr.foo).
     * @return The depth of the profile in the hierarchy.
     */
    protected int getDepth(String ProfileName)
    {
        // start under default
        int depth = 1;
        for(int index = 0; index < ProfileName.length();index++)
        {
            if(ProfileName.charAt(index) == '.')
                depth++;
        }
        return depth;
    }

    
    /**
     * Logs information related to the selectProfile() request.
     * @param userName The current users name.
     * @param profileSet The specified ProfileSet.
     * @param modelName The name of the current model.
     * @param explicitProfileName the name of any Explicit Profiles.
     */
    protected void logSelectionRequest(LogCategory logger, String userName, ProfileSet profileSet, String modelName, String explicitProfileName) {
        StringBuffer names = new StringBuffer(); 
        
        names.append("Selecting profile for user: " + userName); //$NON-NLS-1$
        names.append(" Profile Set: "); //$NON-NLS-1$
        names.append(profileSet.getName());
        names.append(" Model: "); //$NON-NLS-1$
        names.append(modelName);
        
        if(explicitProfileName != null && explicitProfileName.length() > 0)
        {
            names.append(" Explicit Profile: "); //$NON-NLS-1$
            names.append(explicitProfileName);
        }
        
        logger.debug(names.toString());
    }
    

    /**
     * Logs the name of the roles for the specified User.
     * @param userName The name of the current User
     * @param roleType The role type (group, role)
     * @param segments
     */
    protected void logRoles(LogCategory logger, String userName, String roleType, List segments) {
        
        StringBuffer names = new StringBuffer(userName + " belongs to the following "); //$NON-NLS-1$
        names.append(roleType);
        names.append(": "); //$NON-NLS-1$
        for (Iterator iter = segments.iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            names.append(name);
            if(iter.hasNext())
                names.append(", "); //$NON-NLS-1$
        }
        logger.debug(names.toString());
    }
    
    
}
