/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

//Title:        LDAPSelectionHandler
//Description:  Implementation of ProfileSelection interface for selecting
//              Profiles based on a users LDAP Groups.

package com.bowstreet.profiles;

import javax.servlet.http.*;
import java.util.*;
import javax.naming.directory.*;
import javax.naming.*;

import com.bowstreet.dir.DistinguishedName;
import com.bowstreet.BSConfig;
import com.bowstreet.util.*;
import com.bowstreet.webapp.ModelInstanceCreator;
import com.bowstreet.webapp.WebAppData;
import com.bowstreet.webapp.engine.WebAppRuntimeException;

import com.bowstreet.dir.BSInitialLdapContext;


/**
 * This is a sample implementation of a ProfileSelection interface
 * that is used by the "LDAP Selection Handler".
 *
 * This class is used to select a profile by matching a users
 * LDAP groups to a profile within a specified profile set.
 *
 * The definition file for this handler is in located in
 * J2EERoot/WEB-INF/conf/selection_handlers/ldapselectionhandler.xml
 *
 * @see com.bowstreet.profiles.ProfileSelection
 *
 */
public class LDAPSelectionHandler extends SelectionHandlerBase implements SegmentList
{
    // Cache the JNDI properties initialized the first time through
    private static Properties jndiProperties = null;

    // LDAP config info...
    private static String userRootDN = null;
    private static String userNamingAttr = null;
    private static String groupRootDN = null;
    private static String groupMemberAttr = null;
    private static String groupClass = null;

   /** Property name for cached group List in the WebAppData (session by default) */
    final public static String LDAP_GROUPS_CACHE = "bowstreet.ldapSelectionHandler.group.cache"; //$NON-NLS-1$


    // JNDI Property names
    final private static String JNDI_URL = "java.naming.provider.url"; //$NON-NLS-1$
    final private static String JNDI_FAC = "java.naming.factory.initial"; //$NON-NLS-1$
    final private static String JNDI_USER = "java.naming.security.principal"; //$NON-NLS-1$
    final private static String JNDI_PWD = "java.naming.security.credentials"; //$NON-NLS-1$

        // Property names for finding a user dn based on username
    final private static String LDAP_USERS = "bowstreet.ldap.user.root"; //$NON-NLS-1$
    final private static String LDAP_USER_ATTR = "bowstreet.ldap.user.namingAttribute"; //$NON-NLS-1$

        // Property names for doing group membership searches
    final private static String LDAP_GROUPS = "bowstreet.ldap.group.root"; //$NON-NLS-1$
    final private static String LDAP_GROUP_CLASS = "bowstreet.ldap.group.objectClass"; //$NON-NLS-1$
    final private static String LDAP_GROUP_MEMBER = "bowstreet.ldap.group.memberAttribute"; //$NON-NLS-1$

    // Account used by the handler to authenticate to the server,
    // to do the above lookups with
    final private static String LDAP_ACCT_DN = "bowstreet.ldap.account.userdn"; //$NON-NLS-1$
    final private static String LDAP_ACCT_PWD= "bowstreet.ldap.account.userpassword"; //$NON-NLS-1$

    // The connection to LDAP
    private InitialDirContext jndiContext;


    /**
     * This method will select the proper profile by mapping the user segment to a matching profile.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @param modelName The name of the Model that is being generated. This will be the full path of the model relative to the "J2EERoot\WEB-INF\models" directory (e.g. "factory/core/Welcome")
     * @param explicitProfile The name of an explicitly selected profile, or null if there was not one specified. If specified then the user must match the segment on the explicitly selected profile.
     * @param modelInstanceCreator This can be use to instantiate a WebApp Model, which can then be invoked. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @return The name of the selected Profile from the ProfileSet that matches the users segment.
     *
     * @see com.bowstreet.profiles.ProfileSet
     * @see com.bowstreet.webapp.ModelInstanceCreator
     * @see javax.servlet.http.HttpServletRequest
     */
    public String selectProfile(HttpServletRequest request,
                                ProfileSet profileSet,
                                String modelName,
                                String explicitProfile,
                                ModelInstanceCreator modelInstanceCreator)
    {
        String profileName = ProfileSet.DEFAULT;
        Iterator segments = null;
        List groups = null;

        // Always check request for null for cases when generation is run outside the context of the server (i.e. Design time in the IDE).
        if(request != null)
        {
            // see if there is already a list of groups in the users cache, if so use them so we don't hit LDAP everytime.
            groups = getGroupsFromCache(request);

            // if no groups rhen go find them
            if(groups == null)
            {
                // get the user ID of the current user (e.g. msmith)
                String userID = getUserID(request);
                if(userID != null)
                {
                    // build up the list of groups for the user
                    groups = getGroupsForUserID(userID);
                    if(groups != null)
                    {
                        // add the list to the users cache for use later
                        addGroupsToCache(request, groups);
                    }
                }
            }
        }

        // if the explicit profile was specified and it's valid, then just return it.
        if(validateExplicitProfile(request, explicitProfile, profileSet, segments))
            return explicitProfile;

        // find the Profile that matches one of the groups the user is a menber of.
        profileName = getProfileForUser(groups, profileSet.getName(), request);

        return profileName;

    }


    /**
     * This initialize method will get the properties as specified in the
     * selection handler config file, and save them off into static cached
     * objects within this handler class.
     *
     * @param properties A map of properties specified in the config file.
     */
    public void init(Map properties)
    {
        if ((jndiProperties == null) || jndiProperties.isEmpty()) {
            jndiProperties = new Properties();

            // Get the initial JNDI property values from handler config props
            // and copy to JNDI specific properties object that we pass to JNDI
            String jndiURL = (String)properties.get(JNDI_URL);
            jndiProperties.put(JNDI_URL, jndiURL);
            String jndiFactory = (String)properties.get(JNDI_FAC);
            jndiProperties.put(JNDI_FAC, jndiFactory);

            // Get the account info to use for authenticating to LDAP via JNDI
            String ldapAccountDN = (String)properties.get(LDAP_ACCT_DN);
            jndiProperties.put(JNDI_USER, ldapAccountDN);

            // Get the password, unobscure it, then copy to JNDI properties obj
            String ldapAcctPasswd = (String)properties.get(LDAP_ACCT_PWD);
            // System.out.println("Unobscuring: '" + ldapAcctPasswd + "'");
            ldapAcctPasswd = BSConfig.unObscureValue(ldapAcctPasswd);
            // System.out.println("LDAPSelectionHandler Using password: " +
            //                    ldapAcctPasswd);
            jndiProperties.put(JNDI_PWD, ldapAcctPasswd);
        }

        // Which of these we get depends on whether we're being instantiated
        // for profile selection at regen or just segment list at design time.
        userRootDN = (String)properties.get(LDAP_USERS);
        userNamingAttr = (String)properties.get(LDAP_USER_ATTR);
        groupRootDN = (String)properties.get(LDAP_GROUPS);
        groupMemberAttr = (String)properties.get(LDAP_GROUP_MEMBER);
        groupClass = (String)properties.get(LDAP_GROUP_CLASS);
    }


    /**
     * Gets a JNDI/LDAP naming context given the configured JNDI properties
     *
     * @return An InitialDirContext
     */
    private InitialDirContext getJNDIContext()
    {
        // Establish a connection to LDAP
        try {
            InitialDirContext ctx = BSInitialLdapContext.allocInitialLdapContext(jndiProperties, null);
            return ctx;
        } catch (NamingException ne) {
            // Assume caller will handle and log this exception
            throw new WebAppRuntimeException(ne);
        }
    }


    /**
     * Gets a list of groups for the specified username/userid
     *
     * @param userID The ID of the user (eg, msmith).
     * @return A List of Group String that the user is a member of
     */
    private List getGroupsForUserID(String userID) {
        jndiContext = getJNDIContext();
        try {
            String userDN = getUserDN(userID);
            // System.out.println("LDAPSelectionHandler Got UserDN: "+ userDN);

            return getGroups(userDN);
        } finally {
            // Close the connection, but nothing to do if problems doing so.
            try { jndiContext.close(); } catch (NamingException ne) {}
        }
    }


    /**
     * Get a User DN for the specified user - caller should cache in session
     *
     * @param username The username/userID (msmith).
     * @return The distinguished name of the user (cn=msmith,ou=users,o=acme,c=us)
     */
    private String getUserDN(String username) {
        Vector v = new Vector();
        try {
            // Search the entire subtree
            SearchControls sc = new SearchControls();
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String searchFltr = StringUtil.strcat(userNamingAttr,"=",username); //$NON-NLS-1$
            NamingEnumeration ne = jndiContext.search(userRootDN,
                                                      searchFltr,
                                                      sc);
            while (ne.hasMore()) {
                // Add this search result to our vector/list to return.  Note,
                // StringUtil.strcat is a Bowstreet StringAddition optimization
                v.addElement(StringUtil.strcat(((SearchResult)ne.next()).getName(), ",", userRootDN)); //$NON-NLS-1$
            }
        } catch (NamingException e) {
            // Assume the caller will handle/log this exception
            throw new WebAppRuntimeException(e);
        }

        // Bail out if we didn't get exactly ONE LDAP DN for this username
        if (v.size() == 0) {
            throw new WebAppRuntimeException(StringUtil.printf(ProfileRes.getString("LDAPSelectionHandler.0"), //$NON-NLS-1$
                                             username));
        }
        if (v.size() > 1) {
            // Could show list of DNs in this exception, for more detail
            throw new WebAppRuntimeException(StringUtil.printf(ProfileRes.getString("LDAPSelectionHandler.1"), ""+v.size(), //$NON-NLS-1$ //$NON-NLS-2$
                                             username));
        }

        // In this case, we got exactly one DN for username, so return it
        return (String)v.elementAt(0);
    }


    /**
     * Get the groups for the specified userDN - caller should cache in session
     *
     * @param userDN The distinguished name of the user to get group membership of (cn=msmith,ou=dev,o=acme,c=us).
     * @return A List of Group String that the user is a member of
     */
    private List getGroups(String userDN) {
        List list = new ArrayList();
        try {
            // Search the entire subtree
            SearchControls sc = new SearchControls();
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);

            // Build up the search filter to find groups for this user
            // StringUtil.strcat is a Bowstreet string addition optimization
            String searchFltr = StringUtil.strcat("(&(objectclass=",groupClass, //$NON-NLS-1$
                                                  ")(", groupMemberAttr, "=",  //$NON-NLS-1$//$NON-NLS-2$
                                                  userDN, "))"); //$NON-NLS-1$

            // Perform the actual search against the directory.
            NamingEnumeration ne = jndiContext.search(groupRootDN,
                                                      searchFltr,
                                                      sc);
            while (ne.hasMore()) {
                String dn = StringUtil.strcat(((SearchResult)ne.next()).getName(), ",", groupRootDN); //$NON-NLS-1$
                DistinguishedName distinguishedName = new DistinguishedName(dn);
                // Use DistinguishedName to format the dn name so its consistent
                list.add(distinguishedName.toString());
            }
        } catch (NamingException e) {
            // Assume caller will handle/log the exception.
            throw new WebAppRuntimeException(e);
        }

        return list;
    }


    /**
     * Gets a list of the known segments related to this handler.
     *
     * In this handler's case, it's the list of LDAP groups found below the Group container specified in the config file.
     *
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @return An iterator over the List of LDAP Group names as String objects.
     */
    public Iterator getSegments(ProfileSet profileSet)
    {
        jndiContext = getJNDIContext();

        Vector v = new Vector();
        try {
            // Search the entire subtree
            SearchControls sc = new SearchControls();
            sc.setSearchScope(SearchControls.SUBTREE_SCOPE);

            // Build up the search filter to find groups under specified root
            String searchFltr = StringUtil.strcat("(objectclass=",groupClass, //$NON-NLS-1$
                                                  ")"); //$NON-NLS-1$

            // Perform the actual search for the available groups
            NamingEnumeration ne = jndiContext.search(groupRootDN,
                                                      searchFltr,
                                                      sc);
            while (ne.hasMore()) {
                String name = StringUtil.strcat(((SearchResult)ne.next()).getName(), ",", groupRootDN); //$NON-NLS-1$
                DistinguishedName dn = new DistinguishedName(name);
                // Use DistinguishedName to format the dn name so its consistent
                v.addElement(dn.toString());
            }
        } catch (NamingException e) {
            // Assume that the caller will handle/log this exception
            throw new WebAppRuntimeException(e);
        } finally {
            try {
                jndiContext.close();
            } catch (NamingException ne) {
                // Nothing to do here - just trying to close the context...
            }
        }

        return v.iterator();
    }


    /**
     * Tests to see if there is a matching group for the specified profile.
     * Called from validateExplicitProfile(..) in SelectionHandlerBase class.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profile The profile that the match will be performed on.
     * @param segments an Iterator on segment names that the used is a member of. Not uesd for this handler.
     * @return true if one of the segments matches one on the profile, or true if the profile has no segments defined, else false if no match.
     *
     */
    public boolean isSegmentInProfile(HttpServletRequest request, Profile profile, Iterator segments)
    {
        // make sure the Profile really conatins the group.
        List groups = getGroupsFromCache(request);
        if(groups != null)
        {
             return  profileContainsGroup(groups, profile);
        }

        return false;
    }


   /**
     * Finds the first Profile that matches one of the user's Group DN's.
     * This will look for the most derived Profile that matched.
     *
     * @param groups A list of Group String objects, which the user is a member of.
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @return The matching Profile or default Profile if no match was found.
     */
    protected String getProfileForUser(List groups, String profileSetName, HttpServletRequest request)
    {
        String profileName = Profile.DEFAULT;

        if(request != null && groups != null)
        {
            // get the profile that matches one of the groups (segments)
            profileName = getProfileBySegment(profileSetName, groups.iterator());
        }

        return profileName;
    }



    /**
     * Tests if the specified Profile contains a group the the users is a member of.
     *
     * @param groups A list of Group String objects, which the user is a member of.
     * @param profile The Profile to test.
     * @return true if there is a match, else false.
     */
    protected boolean profileContainsGroup(List groups, Profile profile)
    {
        // For each Group (role) associated with the profile
        // See if the user's a member of any of this profile's Group.
        Iterator roleIterator = profile.getRoles();
        while(roleIterator.hasNext())
        {
            String role = (String)roleIterator.next();
            // Is the user is a group of this profile?
            if (groups.contains(role))
            {
                return true;
            }
        }
        return false;
    }


    /**
     * Gets a List of Groups (String) from the users cache.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @return The List of Group Strings from the users cache or null if there were none.
     */
    protected List getGroupsFromCache(HttpServletRequest request)
    {
        List groups = null;

        if(request != null)
        {
            // get the WebAppData from the request
            WebAppData webAppData = (WebAppData)request.getAttribute(WebAppData.REQUEST_PROPERTY);

            if(webAppData != null)
            {
                groups = (List)webAppData.get(LDAP_GROUPS_CACHE);
            }
        }
        return groups;
    }


    /**
     * Adds the List of Strings to the users WebAppData for caching
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param groups List of Group Strings that the user is a member of.
     */
    protected void addGroupsToCache(HttpServletRequest request, List groups)
    {
        if(request != null)
        {
            // get the WebAppData from the request
            WebAppData webAppData = (WebAppData)request.getAttribute(WebAppData.REQUEST_PROPERTY);

            if(webAppData != null)
            {
                // Add the groups to the cache.
                webAppData.put(LDAP_GROUPS_CACHE, groups);
            }
        }
    }

}
