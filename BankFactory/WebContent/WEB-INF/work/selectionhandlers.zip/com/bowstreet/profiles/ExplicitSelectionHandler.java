/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

package com.bowstreet.profiles;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import com.bowstreet.webapp.ModelInstanceCreator;

/**
 * Class that handles only specifying explicit profiles with no validation. If no explicit profile is specified then the default profile is selected.
 * This is useful for testing or for use on Profile Sets where the data is not sensitive to a particular user (e.g. background color, favorite food, etc..).
 */
public class ExplicitSelectionHandler extends SelectionHandlerBase implements SegmentList
{
  /**
     * This method will return the name of the profile from the explicit profile name for the specified profile set. If no explicit profile specified then this will return the default profile ("Default").
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @param profileSet The ProfileSet, which contains the Profile to be selected.
     * @param modelName The name of the Model that is being generated.
     * @param explicitProfile The name of an explicitly selected profile, or null if there was not one specified (Example: "Gold").
     * @param modelInstanceCreator This can be use to instantiate a WebApp Model, which can then be invoked. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @return The name of the profile from the explicit profile name for the specified profile set. If no explicit profile specified then this will return the default profile ("Default").
     *
     * @see com.bowstreet.profiles.ProfileSet
     * @see com.bowstreet.webapp.ModelInstanceCreator
     * @see javax.servlet.http.HttpServletRequest
     */
    public String selectProfile(HttpServletRequest request, ProfileSet profileSet, String modelName, String explicitProfile, ModelInstanceCreator modelInstanceCreator)
    {
        if(explicitProfile == null || explicitProfile.length() == 0)
            return IProfileDefines.DEFAULT;

        return explicitProfile;

    }

    /**
     * Gets a list of the segments related to this handler. In this case an empty Iterator is always returned.
     *
     * @param profileSet The ProfileSet to which the segment names are being set on.
     * @return A Iterator of segment names (String). In this case an empty Iterator is always returned.
     *
     * @see com.bowstreet.profiles.ProfileSet
     *
     */
    public Iterator getSegments(ProfileSet profileSet)
    {
        return emptyIterator;
    }

}