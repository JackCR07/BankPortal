/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

package com.bowstreet.profiles;


import java.util.*;
import javax.servlet.http.*;
import com.bowstreet.webapp.ModelInstanceCreator;
import com.bowstreet.webapp.security.J2EEKnownRolesHandler;
import com.bowstreet.util.NameValuePair;

/**
 * This class is uded by the J2EE Role Profile Selection Handler to select a profile for a user by matching the J2EE Roles that the user is in, to a corresponding role specified in a Profile.
 * For matching this class uses the HttpServletRequest isUserInRole(..) method to compare each Role (Segment) that was specified on each of the Profiles within the Profile Set.
 */
public class J2EERoleProfileSelection extends SelectionHandlerBase implements SegmentList
{

    /**
     * This method will select the correct Profile from the specified ProfileSet by matching the J2EE Role to the role in the profile.
     * For matching this handler class uses the HttpServletRequest isUserInRole(..) method to compare each Role (Segment) that was specified on each of the Profiles within the Profile Set.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @param modelName The name of the Model that is being generated. This will be the full path of the model relative to the "J2EERoot\WEB-INF\models" directory (e.g. "factory/core/Welcome")
     * @param explicitProfile The name of an explicitly selected profile, or null if there was not one specified.
     * @param modelInstanceCreator This can be use to instantiate a WebApp Model, which can then be invoked. Implementers of this method should test this for null.
     * @return The name of the selected Profile from the ProfileSet based on the users J2EE Role.
     *
     * @see com.bowstreet.profiles.ProfileSet
     * @see com.bowstreet.profiles.Profile
     * @see com.bowstreet.webapp.ModelInstanceCreator
     * @see javax.servlet.http.HttpServletRequest
     */
    public String selectProfile(HttpServletRequest request, ProfileSet profileSet, String modelName, String explicitProfileName, ModelInstanceCreator modelInstanceCreator)
    {
        // if the explicit profile was specified and it's valid, then just return it.
        if(validateExplicitProfile(request, explicitProfileName, profileSet, null))
             return explicitProfileName;

        // if there was not an explicit profile then look it up
         String profileName = getProfileForUser(profileSet.getName(), request);

        return profileName;
    }


    /**
     * Gets a list of the segments related to this handler (e.g. "Gold", Silver", "English").
     * For this class this method will get the J2EE roles from the web.xml file.
     *
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @return A Iterator of segment names as String objects. For this class this method will get the J2EE roles from the web.xml file.
     */
    public Iterator getSegments(ProfileSet profileSet)
    {
        J2EEKnownRolesHandler handler = new J2EEKnownRolesHandler();
        Iterator roles = handler.getKnownRoles();
        List knownRoles = new ArrayList();
        while (roles.hasNext()) {
            NameValuePair nvp = (NameValuePair)roles.next();
            knownRoles.add(nvp.getValue());
        }

        return knownRoles.iterator();
    }


   /**
     * Tests to see if there is a matching segment for the specified profile.
     * Called from validateExplicitProfile(..) in SelectionHandlerBase class.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profile The profile that the match will be performed on.
     * @param segments an Iterator on segment names that the used is a member of.
     * @return true if one of the segments matches one on the profile, or true if the profile has no segments defined, else false if no match.
     *
     */
    public boolean isSegmentInProfile(HttpServletRequest request, Profile profile, Iterator segments)
    {

        // For each role associated with the profile
        // See if the user's a member of any of this profile's roles
        Iterator roleIterator = profile.getRoles();
        while(roleIterator.hasNext()) {
            String role = (String)roleIterator.next();

            // Is the user a member of this profile role?
            if (request.isUserInRole(role))
            {
                return true;
            }
        }

        return false;

    }



    /**
     * Finds the first Profile that matches one of the user's J2EE roles.
     * This will look for the most derived Profile that matched.
     *
     * @param profileSetName The name of the ProfileSet, which contains the Profile to be selected.
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @return The matching Profile name or default Profile if no match was found.
     */
    protected String getProfileForUser(String profileSetName, HttpServletRequest request)
    {
        String profileName = Profile.DEFAULT;

        if(request != null)
        {
            // get all the possible segment names in use.
            Iterator segmentsInUse = profileStorageManager.getSegmentsInUse(profileSetName).iterator();

            // get the segments that the user is in (i.e. the ones that match request.isUserInRole(..))
            Iterator segments = getUserSegments(request, segmentsInUse);

            // get the profile that matches one of the segments
            profileName = getProfileBySegment(profileSetName, segments);

        }

        return profileName;
    }


   /**
     * Gets the segments the current user is in.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param knownSegments an Iterator of all the known segments.
     * @return true an Iterator on segment names that the used is in.
     */
    public Iterator getUserSegments(HttpServletRequest request, Iterator knownSegments)
    {
        List segments = new ArrayList();

        // For each role associated with the profile
        // See if the user's a member of any of this profile's roles
        while(knownSegments.hasNext())
        {
            String segment = (String)knownSegments.next();

            // Is the user a member of this profile role?
            if (request.isUserInRole(segment))
            {
                segments.add(segment);
            }
        }

        return segments.iterator();
    }



}