/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

package com.bowstreet.profiles;

import javax.servlet.http.*;
import java.util.*;
import java.io.*;
import com.bowstreet.BSConfig;
import com.bowstreet.util.*;
import com.bowstreet.webapp.ModelInstanceCreator;
import com.bowstreet.webapp.engine.WebAppRuntimeException;

/**
 * This is a sample implementation of a ProfileSelection interface that is used by the "File Segment Handler".
 * This class is used to select a profile by matching a users segment data to a profile within a specified profile set.
 * The segment data is read in from an xml file that contains the mapping information. The default definition file for this
 * is in located in J2EERoot/WEB-INF/conf/selection_handlers/filesegmenthandler.xml.
 * An alternate file can be specified by setting a different "file" property in the handler definition file. Specifying
 * a different files allows this class to be reused by multiple handler definitions.
 *
 * <p>
 * Here is an example of the structure of the segment mapping data file:
 * <pre>
 *      &lt;segments&gt;
 *        &lt;segment name="Gold"&gt;
 *          &lt;user userID="msmith"/&gt;
 *        &lt;/segment&gt;
 *        &lt;segment name="Silver"&gt;
 *          &lt;user userID="bjones"/&gt;
 *        &lt;/segment&gt;
 *        &lt;segment name="English"&gt;
 *          &lt;user userID="msmith"/&gt;
 *          &lt;user userID="bjones"/&gt;
 *        &lt;/segment&gt;
 *      &lt;/segments&gt;
 * </pre>
 *
 * <p>
 * segment name - Defines and names a segment. Each segment can have zero or more users defined.
 * <p>
 * user userID - This maps the user to the parent segment element. This maps the user to the parent segment element. The user ID is the name the user specified when authenticating them self to the server.
 * <p>
 *
 *
 * <p>
 * Here is the contents of the handler file for this class:
 * <pre>
 * &lt;Handler name="File Segment Handler"&gt;
 *   &lt;Description&gt;Handler that maps users to a segment using mapping data from a simple xml file.&lt;/Description&gt;
 *   &lt;Selection class="com.bowstreet.webapp.examples.profileselection.FileSegmentSelectionHandler"&gt;
 *     &lt;Properties&gt;
 *       &lt;Property name="file">factory/profile_segment_data/segments.xml&lt;/Property&gt;
 *     &lt;/Properties&gt;
 *   &lt;/Selection&gt;
 *   &lt;SegmentList class="com.bowstreet.profiles.FileSegmentSelectionHandler" /&gt;
 * &lt;/Handler&gt;
 * </pre>
 * This file describes the following:
 * <p>
 *  Handler name - This is the name of the handler, which will be used as the display name in the Profile Set Manager to allow
 *  the user to select a handler for their profile set.
 * <p>
 *  Description - A short description that specifies the functionality of the handler.
 * <p>
 *  Selection class - The class that implements the ProfileSelection interface. This must include the full package name.
 * <p>
 *  Properties - These are optional name/value pair properties that will be passed as a Map to the init(..) method of your ProfileSelection implementation class.
 * <p>
 *  SegmentList class - The class that implements the SegmentList interface. This must include the full package name. This is
 *   an optional value that is used by a customizer UI to get the list of segments for this handler.
 *
 *
 * @see com.bowstreet.profiles.ProfileSelection
 *
 */
public class FileSegmentSelectionHandler extends SelectionHandlerBase implements SegmentList
{
    // A map of SegmentData where each entry represents that data from a segment file.
    // This is used to cache the data read in accross multiple instance of the FileSegmentSelectionHandler
    private static final Map fileToSegmentData = new Hashtable();

    // This is the current or active SegmentData from the fileToSegmentData Map for this instance of the FileSegmentSelectionHandler.
    private SegmentData segmentData = null;


    // XML tag names in segment file.
    private static final String SEGMENTS = "segments"; //$NON-NLS-1$

    // XML attribute names in segment file.
    private static final String NAME = "name"; //$NON-NLS-1$
    private static final String USER_ID = "userID"; //$NON-NLS-1$


    // The property name for the handler data file. This property must include the path name of the data file relative to the J2EERoot\WEB-INF directory.
    public static final String HANDLER_DATA_FILE = "FileName"; //$NON-NLS-1$

    // This is the default
    public static final String DEFAULT_FILE_NAME = "factory" + File.separatorChar + "profile_segment_data" + File.separatorChar + "segments.xml";  //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$


    /**
     * This method will select the proper profile by mapping the user segment to a matching profile.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @param modelName The name of the Model that is being generated. This will be the full path of the model relative to the "J2EERoot\WEB-INF\models" directory (e.g. "factory/core/Welcome")
     * @param explicitProfile The name of an explicitly selected profile, or null if there was not one specified. If specified then the user must match the segment on the explicitly selected profile.
     * @param modelInstanceCreator This can be use to instantiate a WebApp Model, which can then be invoked. Implementers of this method should test this for null, for cases where generation is done outside the context of the server.
     * @return The name of the selected Profile from the ProfileSet that matches the uses segment.
     *
     * @see com.bowstreet.profiles.ProfileSet
     * @see com.bowstreet.webapp.ModelInstanceCreator
     * @see javax.servlet.http.HttpServletRequest
     */
    public String selectProfile(HttpServletRequest request,
                                ProfileSet profileSet,
                                String modelName,
                                String explicitProfile,
                                ModelInstanceCreator modelInstanceCreator)
    {
        String profileName = ProfileSet.DEFAULT;
        Iterator segments = emptyIterator;

        // Always check request for null for cases when generation is run outside the context of the server (i.e. Design time in the IDE).
        if (request != null)
        {
            // get the user ID of the current user (e.g. msmith)
            String userID = getUserID(request);
            if(userID != null)
            {
                // use the users id to get an iterator of segments they are in.
                segments = segmentData.userIdToSegements.get(userID);
            }
        }

        // if the explicit profile was specified and it's valid, then just return it.
        if(validateExplicitProfile(request, explicitProfile, profileSet, segments))
            return explicitProfile;

        // Call the getProfileBySegment(..) in the base class to match the segments to a profile.
        // If a profile is not found with a matching segment then this method will return the default profile ("Default").
        profileName = getProfileBySegment(profileSet.getName(), segments);

        return profileName;

    }



    /**
     * This initialize method will get the file name from the specified properties and
     * load the segment data from the file into the cache.
     *
     * @param properties A map of properties that are specified in the segment data file.
     */
    public void  init(Map properties)
    {
        String fileName = (String)properties.get(HANDLER_DATA_FILE);

        // If no file is specified in the propeties then use the default
        if(fileName == null || fileName.length() == 0)
            fileName = DEFAULT_FILE_NAME;

        // Build file name relative to the J2EERoot/WEB-INF
        fileName = BSConfig.getHomedir() + File.separatorChar + fileName;

        // See if the file is already in our cache
        segmentData = (SegmentData)fileToSegmentData.get(fileName);

        // If the file was not in the cache or it has been updated then we need to reload it
        if(segmentData == null
                || segmentData.lastModified != segmentData.dataFile.lastModified())
            loadData(fileName);

    }



    /**
     * Gets a list of the segments related to this handler (e.g. "Gold", Silver", "English").
     *
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @return A List of segment names as String objects.
     */
    public Iterator getSegments(ProfileSet profileSet)
    {
        return segmentData.segmentsList.iterator();
    }


    /**
     * Read in the XML file that contains the segment data from the specified file.
     *
     * @param fileName The name of the data file to load segment data from.
     *
     * @example The segment data file has the following structure
     *
     *   <segments>
     *     <segment name="Gold">
     *       <user userID="msmith"/>
     *     </segment>
     *     <segment name="Silver">
     *       <user userID="bjones"/>
     *     </segment>
     *     <segment name="English">
     *       <user userID="msmith"/>
     *       <user userID="bjones"/>
     *     </segment>
     *   </segments>
     *
     */
    protected synchronized void loadData(String fileName)
    {
        // See if the file is already in our cache
        segmentData = (SegmentData)fileToSegmentData.get(fileName);

        // If the is in the cache and it has not been updated then we are done
        if(segmentData != null
                && segmentData.lastModified == segmentData.dataFile.lastModified())
            return;

        // if not already in the cache then create a new one, else we are updating an existing one.
        if(segmentData == null)
        {
            File dataFile = new File(fileName);
            segmentData = new SegmentData();
            segmentData.dataFile = dataFile;
        }
        else
        {
            segmentData.segmentsList.clear();
            segmentData.userIdToSegements.clear();
        }

        Reader reader = null;
        try
        {
            // Read the XML file and populate the userIdToSegements and segmentsList
            FileInputStream fis = new FileInputStream(segmentData.dataFile);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8"); //$NON-NLS-1$
            reader = new BufferedReader(isr);
            IXml data = XmlUtil.parseXml(reader);
            if(data != null)
            {
                IXml segments = data.findElement(SEGMENTS);
                if(segments != null)
                {
                    IXml segment = segments.getFirstChildElement();
                    while(segment != null)
                    {
                        String segmentName = segment.getAttribute(NAME);
                        if(segmentName != null && segmentName.length() > 0)
                        {
                            segmentData.segmentsList.add(segmentName);
                            IXml user = segment.getFirstChildElement();
                            while(user != null)
                            {
                                String userID =  user.getAttribute(USER_ID);
                                if(userID != null && userID.length() > 0)
                                {
                                    segmentData.userIdToSegements.put(userID,
                                                                      segmentName);
                                }

                                user = user.getNextSiblingElement();
                            }
                            segment = segment.getNextSiblingElement();
                        }
                    }
                }
            }
        }
        catch(Exception ex)
        {
            throw new WebAppRuntimeException(ex);
        }
        finally
        {
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch(Exception ex)
            {
                throw new WebAppRuntimeException(ex);
            }
        }

        // save the lastModified time so we can check when the file has changed.
        segmentData.lastModified = segmentData.dataFile.lastModified();

        // now add it to the static cache.
        fileToSegmentData.put(fileName, segmentData);
    }




    /**
     * Inner class used to contain the data structure for a segment data file.
     * There will be one instance of this class for each segment file. This allows us
     * to reuse the FileSegmentSelectionHandler class on multiple data files.
     */
    public static class SegmentData
    {
        /** Holds a reference to segments that users are in. */
        public MapOfLists userIdToSegements = new MapOfLists();
        /**  Holds a list of all the available segments specified in the segment data file.*/
        public List segmentsList = new ArrayList();
        /**  A reference to the file object for the data file.*/
        public File dataFile = null;
        /**  The last modified time of the file when the data was read in.*/
        public long lastModified = 0;
    }


}
