/*
 * Licensed Materials - Property of IBM 
 * 5724-O03
 * (C) Copyright 2002, 2006. IBM Corp. All rights reserved.
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *
 * The Program may contain sample source code or programs, which illustrate
 * programming techniques. You may only copy, modify, and distribute these
 * samples internally. These samples have not been tested under all conditions
 * and are provided to you by IBM without obligation of support of any kind.
 * 
 * IBM PROVIDES THESE SAMPLES "AS IS" SUBJECT TO ANY STATUTORY WARRANTIES THAT
 * CANNOT BE EXCLUDED. IBM MAKES NO WARRANTIES OR CONDITIONS, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR CONDITIONS OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT
 * REGARDING THESE SAMPLES OR TECHNICAL SUPPORT, IF ANY.
 */

package com.bowstreet.profiles;

import com.bowstreet.webapp.ModelInstanceCreator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

/**
 * Profile Selection handler that uses the users Locale to determine, which profile to select
 *
 * This is a sample implementation of a ProfileSelection interface
 * that is used by the "Locale Selection Handler".
 *
 * This class is used to select a profile by matching a users
 * locale to a profile within a specified profile set.
 * 
 * To use this handler you will create a ProfileSet and set its selection handler to the "Locale Selection Handler".
 * Then for each profile you will associate one or more locale names for the profile segment.
 *   For example if you create a profile named "English", you may want to associate "en", and "en_US" with that profile.
 *
 * The definition file for this handler is in located in
 * WEB-INF/conf/selection_handlers/localeselectionhandler.xml
 *
 * @see com.bowstreet.profiles.ProfileSelection
 *
 */
public class LocaleSelectionHandler extends SelectionHandlerBase implements SegmentList
{

    /**
     * This method will select the correct Profile from the specified ProfileSet by matching the users locale to the segment(role) in the profile.
     * For matching this method uses the HttpServletRequest getLocale() method to get the users locale to compare each segment (role) that was specified on each of the Profiles within the Profile Set.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @param modelName The name of the Model that is being generated. This will be the full path of the model relative to the "WEB-INF\models" directory (e.g. "factory/core/Welcome")
     * @param explicitProfile The name of an explicitly selected profile, or null if there was not one specified.
     * @param modelInstanceCreator This can be use to instantiate a WebApp Model, which can then be invoked. Implementers of this method should test this for null.
     * @return The name of the selected Profile from the ProfileSet based on the users locale.
     *
     * @see com.bowstreet.profiles.ProfileSet
     * @see com.bowstreet.profiles.Profile
     * @see com.bowstreet.webapp.ModelInstanceCreator
     * @see javax.servlet.http.HttpServletRequest
     */
    public String selectProfile(HttpServletRequest request, ProfileSet profileSet, String modelName, String explicitProfileName, ModelInstanceCreator modelInstanceCreator)
    {
         // if the explicit profile was specified and it's valid, then just return it.
        if(validateExplicitProfile(request, explicitProfileName, profileSet, null))
             return explicitProfileName;

        // if there was not an explicit profile then match the users locale to a segment on a Profile
        String profileName = getProfileForUser(profileSet.getName(), request);

        return profileName;
    }


   /**
     * Gets the current user locale to be used as segments.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param knownSegments an Iterator of all the known segments.
     * @return an Iterator on segment names that the user is in. This will contain only one locale.
     */
    public Iterator getUserSegments(HttpServletRequest request)
    {
        List segments = new ArrayList();

        String locale = getUserLangPref(request);
        segments.add(locale);

        return segments.iterator();
    }

       
    /**
     * Gets a list of the segments related to this handler (e.g. "en", "en_US", "en_GB_EURO").
     * This method uses the Locale.getAvailableLocales() method to get all the available locales.
     *
     * @param profileSet The ProfileSet, for the profile being selected. Note - The ProfileSet is not populated with all of the Profiles and should not be used to search for matching segments.
     * The ProfileSet will typically contain only the structural information and the default Profile.
     * @return A Iterator of segment names as String objects. For this class this method will get the locales from a call to the Locale.getAvailableLocales() method.
     */
    public Iterator getSegments(ProfileSet profileSet)
    {
        List knownRoles = new ArrayList();

        Locale[] locales = Locale.getAvailableLocales();
        
        for (int i = 0; i < locales.length; i++)
        {
            Locale locale = locales[i];
            knownRoles.add(locale.toString());
        }
 
        Collections.sort(knownRoles); 
 
        return knownRoles.iterator();
    }


   /**
     * Tests to see if there is a matching segment for the specified profile.
     * Called from validateExplicitProfile(..) in SelectionHandlerBase class.
     *
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @param profile The profile that the match will be performed on.
     * @param segments an Iterator on segment names that the used is a member of.
     * @return Always returns true.
     *
     */
    public boolean isSegmentInProfile(HttpServletRequest request, Profile profile, Iterator segments)
    {
        // Allow all
        return true;
    } 
   
    
   /**
     * Finds the first Profile that matches the user's locale name.
     * This will look for the most derived Profile where the segment matches the users locale.
     *
     * @param profileSetName The name of the ProfileSet, which contains the Profile to be selected.
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @return The matching Profile name or default Profile if no match was found.
     */
    protected String getProfileForUser(String profileSetName, HttpServletRequest request)
    {
        String profileName = Profile.DEFAULT;

        if(request != null)
        {
            // get the segments that the user is in
            Iterator segments = getUserSegments(request);

            // get the profile that matches one of the segments
            profileName = getProfileBySegment(profileSetName, segments);

        }

        return profileName;
    }
    
    
    /**
     * Gets name of the locale with the language, country and variant separated by underbars.
     * The language is always lower case, and country is always upper case.
     * If the language is missing, the string will begin with an underbar.
     * If both the language and country fields are missing, this method will return an empty string. 
     * 
     * @param request The HttpServletRequest for the current request. This can be used to get additional information about the requestor. Implementers of this method should test this for null.
     * @return String The users locale as a string (e.g. "en", "de_DE", "_GB", "en_US")
     */
    protected String getUserLangPref(HttpServletRequest request)
    {
        Locale locale = Locale.getDefault();
        String pref = ""; //$NON-NLS-1$
 
        if(request != null)
        {
            // Gets the locale of the preferred language.  
            // If there is more than one preferred language, the one with the highest preference is returned
            locale = request.getLocale();
        }
        
        if(locale != null)
            pref = locale.toString();

        return pref;
    }
       
}

